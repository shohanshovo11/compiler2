#include <iostream>
using namespace std;
class SymbolInfo
{
    string lexeme,token_name;
public:
    string code;
    SymbolInfo()
    {
        lexeme="";
        token_name="";
        code="";
    }
    SymbolInfo(string s,string t)
    {
        lexeme=s;
        token_name=t;
        code="";
    }
    string get_lexeme()
    {
        return lexeme;
    }
    string getToken()
    {
        return token_name;
    }
};