#include<bits/stdc++.h>
using namespace std;
#define MOD 15
int globalScope = 1;
class SymbolInfo
{
    string symbol,symbolType;
public:
    SymbolInfo(string symbol,string symbolType)
    {
        this->symbol = symbol;
        this->symbolType = symbolType;
    }
    string getSymbol()
    {
        return symbol;
    }
    string getSymbolType()
    {
        return symbolType;
    }
    void setSymbol(string symbol)
    {
        this->symbol = symbol;
    }
    void setSymbolType(string symbolType)
    {
        this->symbolType = symbolType;
    }
};
class ScopeTable
{
public:
    vector<SymbolInfo>*scope;
    string id;
    int n;
    int lst;
    ScopeTable(string parent_id,string current_id,int n)
    {
        scope = new vector<SymbolInfo>[n];
        current_id = "."+current_id;
        parent_id += current_id;
        this->id = parent_id;
        lst = 1;
        this->n = n;
    }
    ScopeTable(int n,string parent_id,string current_id)
    {
        scope = new vector<SymbolInfo>[n];
        this->n = n;
        id = parent_id;
        id +=".";
        id += current_id;
        lst = 1;
    }
    ScopeTable(int n)
    {
        this->n = n;
        scope = new vector<SymbolInfo>[n];
        lst = 1;
    }
    ScopeTable(string root,int n)
    {
        scope = new vector<SymbolInfo>[n];
        this->id = root;
        this->n = n;
        lst = 1;
    }
    bool insert(string name,string type);
    int hashf(string name);
    SymbolInfo* lookUp(string name,stack<ScopeTable>sst);
    bool del(string name);
    void print();
    string getID();
    int getSize();
    void updateLst();
};
void ScopeTable::updateLst()
{
    this->lst++;
    return;
}
string ScopeTable::getID()
{
    return id;
}
int ScopeTable::getSize()
{
    return n;
}
int ScopeTable::hashf(string name)
{
    int sum = 0;
    for(int i=0; i<name.length(); i++)
    {
        sum+=name[i];
    }
    return sum%n;
}
bool ScopeTable::insert(string name,string type)
{
    int idx = hashf(name);
    for(auto x:scope[idx])
    {
        if(x.getSymbol()==name && x.getSymbolType()==type)
        {
            return false;
        }
    }
    SymbolInfo sf = SymbolInfo(name,type);
    cout<<"Inserted in Scope Table# "<<id<<" "<<idx<<","<<scope[idx].size()<<endl;
    scope[idx].push_back(sf);
    return true;
}
SymbolInfo* ScopeTable::lookUp(string name,stack<ScopeTable>sst)
{
    int idx = hashf(name);
    SymbolInfo *sf;
//    for(int i=0;i<scope[idx].size();i++)
//    {
//        sf = &scope[idx][i];
//        if(sf->getSymbol()==name)
//        {
//            cout<<"Found in Scope Table# "<<id<<" at position "<<idx<<","<<i<<endl;
//            return sf;
//        }
//    }
    while(sst.size()!=0)
    {
        ScopeTable scptbl = sst.top();
        for(int i=0; i<scptbl.scope[idx].size(); i++)
        {
            sf = &scptbl.scope[idx][i];
            if(sf->getSymbol()==name)
            {
                cout<<"Found in Scope Table# "<<scptbl.getID()<<" at position "<<idx<<","<<i<<endl;
                return sf;
            }
        }
        sst.pop();
    }
    cout<<"Symbol Info not found."<<endl;
    return nullptr;
}
bool ScopeTable::del(string name)
{
    int idx = hashf(name);
    for(auto it = scope[idx].begin();it!=scope[idx].end();it++)
    {
        if(it->getSymbol()==name)
        {
            cout<<"Deleted"<<endl;
            scope[idx].erase(it);
            return true;
        }
    }
    return false;
}
void ScopeTable::print()
{
    cout<<"Scope Table# "<<id<<endl;
    for(int i=0;i<n;i++)
    {
        cout<<i<<"-->  ";
        for(int j=0;j<scope[i].size();j++)
        {
            cout<<"< "<< scope[i][j].getSymbol() <<":"<< scope[i][j].getSymbolType() << ">  ";
        }
        cout<<endl;
    }
    cout<<endl<<endl;
    return;
}

class SymbolTable
{
    vector<SymbolInfo>symTable[MOD];
public:
    bool insert(string symbol,string symbolType);
    int hashf(string symbol);
    int lookup(string symbol);
    void delInfo(string symbol);
    void print();
    void enterScope(stack<ScopeTable>&st,int n);
    void exitScope(stack<ScopeTable>&st);
    void printCurrent(ScopeTable scptbl);
    void printAll(stack<ScopeTable>st);
};
void SymbolTable::printCurrent(ScopeTable scptbl)
{
    scptbl.print();
    return;
}
void SymbolTable::printAll(stack<ScopeTable>st)
{
    while(st.size()!=0)
    {
        ScopeTable stt = st.top();
        stt.print();
        st.pop();
    }
    return;
}
void SymbolTable::enterScope(stack<ScopeTable>&st,int n)
{
    if(st.size()==0)
    {
        st.push(ScopeTable(to_string(globalScope),n));
    }
    else
    {
        ScopeTable curr = st.top();
        string parID = curr.getID();
        string currID = to_string(curr.lst);
        st.push(ScopeTable(parID,currID,n));
    }
    ScopeTable curr = st.top();
    cout<<"New ScopeTable with id "<<curr.getID()<<" created"<<endl;
    return;
}
void SymbolTable::exitScope(stack<ScopeTable>&st)
{
    if(st.size()==0)
    {
        cout<<"Scope Table is Empty"<<endl;
    }
    else
    {
        ScopeTable tmpSt = st.top();
        cout<<"ScopeTable with id "<<tmpSt.getID()<<" removed"<<endl;
        for(int i=0;i<tmpSt.getSize();i++)
        {
            for(int j=0;j<tmpSt.scope[i].size();j++)
            {
                SymbolInfo smb = tmpSt.scope[i][j];
                this->delInfo(smb.getSymbol());
            }
        }
        st.pop();
        if(st.size()!=0)
        {
            st.top().updateLst();
        }
        else globalScope++;
    }
    return;
}
int SymbolTable::hashf(string symbol)
{
    int sum = 0;
    if(symbol.length()>=1)sum+=symbol[0];
    if(symbol.length()>=2)sum+=symbol[1];
    if(symbol.length()>=3)sum+=symbol[2];
    return ((sum*94)%MOD);
}
bool SymbolTable::insert(string symbol,string symbolType)
{
    SymbolInfo si = SymbolInfo(symbol,symbolType);
    int idx = hashf(symbol);
    int sz = symTable[idx].size();
    for(auto x:symTable[idx])
    {
        if(x.getSymbol()==symbol)
        {
            cout<<"Symbol is already present"<<endl;
            return false;
        }
    }
    symTable[idx].push_back(si);
    cout<<"Inserted at position of SymbolTable "<<idx<<","<<sz<<endl;
    return true;
}
int SymbolTable::lookup(string symbol)
{
    int idx = hashf(symbol);
    int index = 0;
    for(auto obj:symTable[idx])
    {
        if(obj.getSymbol()==symbol)
        {
            cout<<"Found at "<<idx<<","<<index<<endl;
            return idx;
        }
        index++;
    }
    cout<<"Symbol not found"<<endl;
    return -1;
}
void SymbolTable::delInfo(string symbol)
{
    int idx = hashf(symbol);
    int id = 0;
    for(auto it = symTable[idx].begin();it!=symTable[idx].end();it++)
    {
        if(it->getSymbol()==symbol)
        {
            cout<<"Deleted from "<<idx<<", "<<id<<endl;
            symTable[idx].erase(it);
            return;
        }
        id++;
    }
    cout<<"Symbol not found."<<endl;
    return;
}
void SymbolTable::print()
{
    int sz = MOD;
    for(int i=0;i<sz;i++)
    {
        cout<<i<<" -> ";
        for(int j=0;j<symTable[i].size();j++)
        {
            cout<<"<"<<symTable[i][j].getSymbol()<<", "<<symTable[i][j].getSymbolType()<<">"<<" ";
        }
        cout<<endl;
    }
}

int main(){
    string inpTyp,inpSymbol,inpSymType;
    SymbolTable st;
    string emnoi = "1";
    stack<ScopeTable>stk_scope;
    int exit = 0;
    int num;    cin>>num;
    getchar();
    ScopeTable scope(emnoi,num);
    stk_scope.push(scope);

    while(exit==0)
    {
        string inp; cin>>inp;
        if(inp=="I")
        {
            string tm1,tm2;
            cin>>tm1>>tm2;
            if(st.insert(tm1,tm2))
            {
                if(stk_scope.size()!=0)
                {
                    stk_scope.top().insert(tm1,tm2);
                }
                else
                {
                    cout<<"No ScopeTable was found"<<endl;
                }
            }
        }
        else if(inp=="L")
        {
            string toLook;  cin>>toLook;
            st.lookup(toLook);
            stk_scope.top().lookUp(toLook,stk_scope);
        }
        else if(inp=="D")
        {
            string toDel;   cin>>toDel;
            st.delInfo(toDel);
            stk_scope.top().del(toDel);
        }
        else if(inp=="P")
        {
            string action;  cin>>action;
            if(action=="A")
            {
                st.printAll(stk_scope);
            }
            else if(action=="C")
            {
                st.printCurrent(stk_scope.top());
            }
        }
        else if(inp=="S")
        {
            st.enterScope(stk_scope,num);
        }
        else if(inp=="E")
        {
            st.exitScope(stk_scope);
        }
        else if(inp=="exit")
        {
            exit = 1;
        }
        else
        {
            cout<<"Invalid input"<<endl;
        }
    }




    return 0;
}
