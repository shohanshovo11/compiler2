#include<bits/stdc++.h>
#include<cstring>
using namespace std;
#define MOD 15

class SymbolInfo
{
    string symbol,symbolType;
public:
    SymbolInfo(string symbol,string symbolType)
    {
        this->symbol = symbol;
        this->symbolType = symbolType;
    }
    string getSymbol()
    {
        return symbol;
    }
    string getSymbolType()
    {
        return symbolType;
    }
    void setSymbol(string symbol)
    {
        this->symbol = symbol;
    }
    void setSymbolType(string symbolType)
    {
        this->symbolType = symbolType;
    }
};
class SymbolTable
{
    vector<SymbolInfo>symTable[MOD];
public:
    int insert(string symbol,string symbolType);
    int hashf(string symbol);
    int lookup(string symbol);
    void delInfo(string symbol);
    void print(FILE* outlog);
};
int SymbolTable::hashf(string symbol)
{
    int sum = 0;
    if(symbol.length()>=1)sum+=symbol[0];
    if(symbol.length()>=2)sum+=symbol[1];
    if(symbol.length()>=3)sum+=symbol[2];
    return ((sum*94)%MOD);
}
int SymbolTable::insert(string symbol,string symbolType)
{
    // ofstream filelog("202114094_log.txt",ios::app);
    // ofstream filetoken("202114094_token.txt",ios::app);
    SymbolInfo si = SymbolInfo(symbol,symbolType);
    int idx = hashf(symbol);
    int sz = symTable[idx].size();
    for(auto x:symTable[idx])
    {
        if(x.getSymbol()==symbol)
        {
            // filelog<<symbol<<" variable already exists in symbol table"<<endl;
            return 0;
        }
    }
    symTable[idx].push_back(si);
    // filelog<<"Token "<<symbolType<<" Lexeme "<<symbol<<" found"<<endl;
    // filelog.close();
    // filetoken.close();
    return 1;
}
int SymbolTable::lookup(string symbol)
{
    int idx = hashf(symbol);
    int index = 0;
    for(auto obj:symTable[idx])
    {
        if(obj.getSymbol()==symbol)
        {
            cout<<"Found at "<<idx<<","<<index<<endl;
            return idx;
        }
        index++;
    }
    cout<<"Symbol not found"<<endl;
    return -1;
}
void SymbolTable::delInfo(string symbol)
{
    int idx = hashf(symbol);
    int id = 0;
    for(auto it = symTable[idx].begin();it!=symTable[idx].end();it++)
    {
        if(it->getSymbol()==symbol)
        {
            cout<<"Deleted from "<<idx<<", "<<id<<endl;
            symTable[idx].erase(it);
            return;
        }
        id++;
    }
    cout<<"Symbol not found."<<endl;
    return;
}
void SymbolTable::print(FILE* outlog)
{
    int sz = MOD;
    for(int i=0;i<sz;i++)
    {
        fprintf(outlog,"%d ->",i);
        // outlog<<i<<" -> ";
        for(int j=0;j<symTable[i].size();j++)
        {
            fprintf(outlog,"<%s, %s> ",symTable[i][j].getSymbol().c_str(),symTable[i][j].getSymbolType().c_str());
            // filelog<<"<"<<symTable[i][j].getSymbol()<<", "<<symTable[i][j].getSymbolType()<<">"<<" ";
        }
        fprintf(outlog,"\n");
    }
}